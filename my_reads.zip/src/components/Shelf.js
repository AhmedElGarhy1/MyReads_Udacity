import React from "react";
import Book from "./Book";

const Shelf = ({ books, shelfName, changeBook }) => {
  return (
    <div className="bookshelf">
      <h2 className="bookshelf-title">{shelfName}</h2>
      <div className="bookshelf-books"></div>
      <ol className="books-grid">
        {books.length > 0 &&
          books.map((book) => (
            <li key={book.id}>
              <Book book={book} changeBook={changeBook} />
            </li>
          ))}
      </ol>
    </div>
  );
};

export default Shelf;
