import React, { useState } from "react";
import { Link } from "react-router-dom";
import Book from "../components/Book";
import { search } from "../utils/BooksAPI";

const Search = ({ changeBook }) => {
  const [books, setBooks] = useState([]);
  const [query, setQuery] = useState("");
  const [error, setError] = useState(false);
  const filter = (e) => {
    const value = e.target.value;
    setQuery(value);
    if (!value) return setBooks([]);
    setError(false);
    search(value.trim(), 10).then((books) => {
      if (books.error) {
        setBooks([]);
        return setError(true);
      }
      setBooks(books);
    });
  };
  return (
    <div className="search-books">
      <div className="search-books-bar">
        <Link to="/" className="close-search">
          Close
        </Link>

        <div className="search-books-input-wrapper">
          <input
            value={query}
            onChange={filter}
            type="text"
            placeholder="Search by title or author"
          />
        </div>
      </div>
      <div className="search-books-results">
        <ol className="books-grid">
          {error && <div>Can't Find any Book</div>}
          {books &&
            books.map((book) => (
              <li key={book.id}>
                <Book book={book} changeBook={changeBook} />
              </li>
            ))}
        </ol>
      </div>
    </div>
  );
};

export default Search;
