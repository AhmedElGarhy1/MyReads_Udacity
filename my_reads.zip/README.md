# MyReads App

is an app that you can specify the books that you had already read , want to read,or Reading now.

## how to start the project

npm install
npm start
then the project will start

## what dependance i had installed

react-router-dom
